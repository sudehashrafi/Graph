﻿using System;
using MathNet.Numerics;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Double;
using MathNet.Numerics.LinearAlgebra.Factorization;
using MathNet.Numerics.LinearAlgebra.Complex;

namespace graph3
{
    class Program
    {
        static void Main(string[] args)
        {
            bool[] proof = new bool[2];

            Console.WriteLine("plz enter your matrix size : ");
            int n = int.Parse(Console.ReadLine());

            double[,] inputMatrix = new double[n, n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    inputMatrix[i, j] = int.Parse(Console.ReadLine());
                }
            }

            Console.WriteLine("your matrix is : ");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(inputMatrix[i, j] + " ");
                }
                Console.WriteLine();
            }



            Matrix<double> matrix = Matrix<double>.Build.DenseOfArray(inputMatrix);
            Vector<System.Numerics.Complex> meghdarVizhe = matrix.Evd().EigenValues;
            Matrix<double> bordarVizhe = matrix.Evd().EigenVectors;

            Console.WriteLine(" MeghdarVizhe : ");
            for (int i = 0; i < meghdarVizhe.Count; i++)
            {
                Console.WriteLine(meghdarVizhe[i].Real.Round(1));
            }
            for (int i = 0; i < 1; i++)
            {
                for (int j = 0; j < bordarVizhe.RowCount; j++)
                {

                }
                Console.WriteLine();
            }
            Console.WriteLine(bordarVizhe.ToString());


            Console.WriteLine("dobakhshi : " + DoBakhshi(meghdarVizhe , n , proof , bordarVizhe));

            Console.WriteLine("tedade moalefe ha  : " + ComponentNum(meghdarVizhe));



            Console.WriteLine("plz enter your second matrix size : ");
            int n2 = int.Parse(Console.ReadLine());

            Console.WriteLine("plz enter your second matrix  : ");
            double[,] inputMatrix2 = new double[n2, n2];
            for (int i = 0; i < n2; i++)
            {
                for (int j = 0; j < n2; j++)
                {
                    inputMatrix2[i, j] = int.Parse(Console.ReadLine());
                }
            }

            

            Matrix<double> matrix2 = Matrix<double>.Build.DenseOfArray(inputMatrix2);
            Vector<System.Numerics.Complex> meghdarVizhe2 = matrix2.Evd().EigenValues;
            Matrix<double> bordarVizhe2 = matrix2.Evd().EigenVectors;

            Console.WriteLine("bahs dar rabte ba isomorphic : " +
                "**agr false bargardand yani yaghinan isomorphic nistand va agr " +
                "true bud yani emkan dard k isomorphic bashand vali esbati baraye an nist .**  : "
                + Isomorphic(meghdarVizhe , meghdarVizhe2));

            


        }

        //------------------check kardne 2bakhshi------------------------------------
        static bool DoBakhshi(Vector<System.Numerics.Complex> meghdarVizhe , int n, bool[] proof , Matrix<double> bordarVizhe)
        {
            bool dobakhshi = true;

            for (int i = 0; i < meghdarVizhe.Count; i++)
            {
                if (!proof[0] &&  Compare(meghdarVizhe[i].Real.Round(1) , (double)n/2 , 0.2f) )
                {
                    proof[0] = true;
                }
                else if (!proof[1] && Compare(meghdarVizhe[i].Real.Round(1), (double)-n/ 2, 0.2f))
                {
                    proof[1] = true;
                }
                else if (meghdarVizhe[i].Real.Round(1) != 0)
                {
                    dobakhshi = false;
                    return dobakhshi; 
                }

                
            }
            if(!proof[1] || !proof[0])
            {
                dobakhshi = false; 
            }

            if (dobakhshi)
            {
                for (int i = 0; i <bordarVizhe.RowCount; i++)
                {

                    if (bordarVizhe[i ,0] < 0)
                        Console.WriteLine("Node " + i + " in component 1");
                    else
                        Console.WriteLine("Node " + i + " in component2");
                }
            }

            return dobakhshi; 


            
        }

        static bool Compare(double num1 , double num2 , double deqat)
        {
            if(num1 >= (num2-deqat) && num1 <= (num2 + deqat))
            {
                return true; 
            }
            return false; 

        } 

        //----------------mohasebe tedad moalefeha ------------------------------------

        static int ComponentNum(Vector<System.Numerics.Complex> meghdarVizhe)
        {
            int component = 0;
            for (int i = 0; i < meghdarVizhe.Count; i++)
            {
                if (meghdarVizhe[i].Real.Round(1) == 0)
                    component++;
            }
            return component; 
        }

        //---------------check kardn isomorphism---------------------------------------

        static bool Isomorphic(Vector<System.Numerics.Complex> meghdarVizhe1, Vector<System.Numerics.Complex> meghdarVizhe2)
        {
            bool isomorphic = true;
            if (meghdarVizhe1.Count != meghdarVizhe2.Count)
            {
                isomorphic = false; 
            }
            else
            {
                for (int i = 0; i < meghdarVizhe1.Count; i++)
                {
                    if (meghdarVizhe1[i].Real.Round(1) != meghdarVizhe2[i].Real.Round(1))
                    {
                        isomorphic = false;
                        break;
                    }
                }
                
            }
            return isomorphic; 

        }

    }
}

      
   