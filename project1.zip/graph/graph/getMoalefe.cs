﻿using System;
using System.Collections.Generic;
using System.Text;

namespace graph
{
    class getMoalefe
    {

        bool[] isPassed;

         public int moalefeNum ;


        public List<List<int>> MoalefehaList;

        public int isContain()
        {
            for(int i=0; i< isPassed.Length ; i++)
            {
                if (!isPassed[i])
                {
                    return i;
                }
            }
            return -1; 
        }
        public void MoalefeNum(int[,] matrix , int totalNode)
        {
            MoalefehaList = new List<List<int>>() ;
            
            isPassed = new bool [totalNode] ;
            moalefeNum = 0;

            while (isContain() != -1)
            {
                MoalefehaList.Add(new List<int>()); 

                GoThrough(matrix, isContain(), totalNode);

                moalefeNum++; 

            }

            for(int i=0; i < MoalefehaList.Count; i++)
            {
                for(int j =0; j < MoalefehaList[i].Count; j++)
                {
                    Console.Write(MoalefehaList[i][j] + " ");
                }
                Console.WriteLine();
            }


        }
        public void GoThrough(int[,] matrix, int n, int totalNode)
        {
            

            if (!isPassed[n])
            {
                isPassed[n] = true;
                MoalefehaList[moalefeNum].Add(n); 

            }
                
            for (int i = 0; i < totalNode; i++)
            {
                if (matrix[n, i] == 1 && n != i)
                {
                    if (!isPassed[i])
                        GoThrough(matrix, i, totalNode);
                }
            }
        }
    }
}
