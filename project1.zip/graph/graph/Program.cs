﻿using System;
using System.Collections.Generic;

namespace graph
{
   
    class Program
    {
      
       
        static void Main(string[] args)
        {
            Console.WriteLine("plz enter your matrix size : ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("your matrix size is :  " + n);

            int[,] matrix = new int[n, n];

            Console.WriteLine("plz enter your matrix : ");

            for ( int i=0 ; i<n ; i++ )
            {
                for(int j = 0; j< n; j++)
                {
                    matrix[i,j] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("your matrix is : ");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(matrix[i,j] + " ");
                }
                Console.WriteLine();
            }


            GraphKinds g1 = new GraphKinds();

            //----------TOHI------------------------------------------------------

            if(g1.Tohi(matrix, n)){
                Console.WriteLine("*** YOUR GRAPH IS TOHI ***");
            }
            else
                Console.WriteLine("*** YOUR GRAPH IS NOT TOHI ***");

            //---------MONTAZAM----------------------------------------------------

            if(g1.Montazam(matrix, n) && !g1.Tohi(matrix, n) && g1.Sade(matrix, n))
                Console.WriteLine("*** YOUR GRAPH IS MONTAZAM ***");

            else if(g1.Montazam(matrix, n) && g1.Tohi(matrix, n))
                Console.WriteLine("*** YOUR GRAPH IS TOHI SO IT IS 0 M0NTAZAM ***");
            else
                Console.WriteLine("*** YOUR GRAPH IS NOT MONTAZAM ***");
            
            //---------kamel----------------------------------------------------

            if (g1.Kamel(matrix, n) && !g1.Tohi(matrix, n) && g1.Sade(matrix, n))
                Console.WriteLine("*** YOUR GRAPH IS kamel ***");

            else
                Console.WriteLine("*** YOUR GRAPH IS NOT KAMEL ***");

            //----------sade----------------------------------------------------------

            if(g1.Sade(matrix , n) && !g1.Jahatdar(matrix, n))
                Console.WriteLine("*** YOUR GRAPH IS SADE ***");
            else
                Console.WriteLine("*** YOUR GRAPH IS NOT SADE ***");

            //----------jahatdar-------------------------------------------------------

            if (g1.Jahatdar(matrix, n))
                Console.WriteLine("*** YOUR GRAPH IS JAHATDAR ***");
            else
                Console.WriteLine("*** YOUR GRAPH IS NOT JAHATDAR ***");

            //----------madari-------------------------------------------------------

            if (g1.Madari(matrix, n) && g1.Sade(matrix , n))
                Console.WriteLine("*** YOUR GRAPH IS Madari ***");
            else
                Console.WriteLine("*** YOUR GRAPH IS NOT Madari ***");

            //------charkhi----------------------------------------------------------

            if (g1.Charkhi(matrix, n) && g1.Sade(matrix, n))
                Console.WriteLine("*** YOUR GRAPH IS CHARKHI ***");
            else
                Console.WriteLine("*** YOUR GRAPH IS NOT CHARKHI ***");

            //------2bakhshi----------------------------------------------------------

            if (g1.DoBakhshi(matrix, n) && g1.Sade(matrix, n))
                Console.WriteLine("*** YOUR GRAPH IS 2BAKHSHI ***");
            else
                Console.WriteLine("*** YOUR GRAPH IS NOT 2BAKHSHI ***");

            //-----2BAKHSHIKAMEL-------------------------------------------------------

            if (g1.DoBakhshiKamel(matrix, n) && g1.Sade(matrix, n))
                Console.WriteLine("*** YOUR GRAPH IS 2BAKHSHIKAMEL ***");
            else
                Console.WriteLine("*** YOUR GRAPH IS NOT 2BAKHSHIKAMEL ***");

            //------VOGHU------------------------------------------------------

            GetVoghu g3 = new GetVoghu();
            g3.VoghuMatrix(matrix, n);

            //---tedad_derakht_faragir----------------------------------------------

            FaragirNum faragirNum = new FaragirNum();
            faragirNum.Calculate_D_Matrix(matrix, n);
            faragirNum.Calculate_Q_Matrix(matrix , n);
            faragirNum.Calculate_Q_Bar_Matrix(n);
            faragirNum.CalculateDeterminan(n);
            faragirNum.CalculateFaragirNum();

            //------------getMoalefe--------------------------------------------

            getMoalefe m = new getMoalefe();
            Console.WriteLine("moalefe haye graph shoma : ");
            Console.WriteLine("tedad satr ha neshan dahande tedad moalefe ha va adad adad e har satr raas haye har moalefe ast ... ");

            m.MoalefeNum(matrix , n); 
            
            


            //-------------------------------------------------------------------

            Console.WriteLine(" SIZE E MATRIX DOVOM : ");

            int n2 = int.Parse(Console.ReadLine());


            Console.WriteLine(" BARAYE CHECK KARDN YEKRIKHTI MATRIX BAADI RA VARED KONID : ");

            int[,] matrix_2 = new int[n2, n2]; 

            for (int i = 0; i < n2; i++)
            {
                for (int j = 0; j < n2; j++)
                {
                    matrix_2[i, j] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("your second matrix is : ");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(matrix_2[i, j] + " ");
                }
                Console.WriteLine();
            }

            Yekrikhti yekrikhti = new Yekrikhti();
            
            Console.WriteLine("natije yekrikhti : " + yekrikhti.YekrikhtiCheck(matrix, n, matrix_2, n2));






        }
    }
}
