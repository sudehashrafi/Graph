﻿using System;
using System.Collections.Generic;
using System.Text;

namespace graph
{
    class GraphKinds
    {
        bool[] isPassed;

        Queue<int> queueDoBakhshi = new Queue<int>() ;

        public const int noColor = 0;
        public const int red = 1;
        public const int blue = 2;

        int[] colored; 

        //--------2bakhshi-----------------------------

        public bool DoBakhshi(int[,] matrix , int n )
        {
            

            colored = new int[n];

            colored[0] = red;
            queueDoBakhshi.Enqueue(0);
            int element, neighbor;

            while(queueDoBakhshi.Count != 0)
            {
                element = queueDoBakhshi.Dequeue();
                neighbor = 0;

                while(neighbor < n)
                {
                    if(neighbor == element)
                    {
                        neighbor++;
                        continue; 
                    }
                    else if(matrix[element , neighbor] ==1 && colored[element] == colored[neighbor])
                    {
                        return false; 
                    }
                    else if(matrix[element, neighbor] == 1 && colored[neighbor] == noColor) {
                        if (colored[element] == red)
                        {
                            colored[neighbor] = blue;
                        }
                        else
                            colored[neighbor] = red;
                        queueDoBakhshi.Enqueue(neighbor); 
                    }

                    neighbor++; 
                }
            }

            return true ;

        }

        //---------2bakhshiKAMEL--------------------------------

        public bool DoBakhshiKamel (int[,] matrix , int n)
        {
            if (!DoBakhshi(matrix, n))
                return false;

            int part1 = 0;
            int part2 = 0;

            for(int i=0; i< n; i++)
            {
                if (colored[i] == red)
                    part1++;
                else
                    part2++;
            }

            GetVoghu g5 = new GetVoghu(); 

            int totalYal = part1 * part2;
            if (g5.CalculateYalNum(matrix, n) == totalYal)
                return true;
            else
                return false; 
        }

        

        //--------ROWTOTAL----------------------------
        public int[] RowTotal(int[,] matrix, int n)
        {
            int[] rowTotal = new int[n];

            for (int i = 0; i < n; i++)
            {

                for (int j = 0; j < n; j++)
                {
                    rowTotal[i] += matrix[i, j];
                }

            }

            return rowTotal;

        }
        //-----tughe----------------------------------
        public bool Tughe(int[,] matrix, int n)
        {
            bool tugheBool = false; 

            for (int i = 0; i < n; i++)
            {

                for (int j = 0; j < n; j++)
                {
                    if (i == j && matrix[i, j] != 0)
                    {
                        tugheBool = true;
                        break;
                    }
                     
                }

            }

            return tugheBool;
        }
        //----------chandgane-------------------------

        public bool Chandgane(int[,] matrix, int n)
        {
            bool chandganeBool = false;

            for (int i = 0; i < n; i++)
            {

                for (int j = 0; j < n; j++)
                {
                    if (matrix[i,j] > 1)
                    {
                        chandganeBool = true;
                        break;
                    }
                    
                }

            }

            return chandganeBool;
        }

        //---------SADE------------------------------

        public bool Sade(int[,] matrix, int n)
        {
            bool sadeBool = true;

            for (int i = 0; i < n; i++)
            {

                for (int j = 0; j < n; j++)
                {
                    if (Tughe(matrix , n) | Chandgane(matrix, n))
                    {
                        sadeBool = false;
                        break;
                    }
                    
                }

            }
            return sadeBool;
        }

        //--------tohi--------------------------------
        public bool Tohi(int[,] matrix, int n)
        {
            bool tohiBool = true;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (matrix[i, j] != 0)
                    {
                        tohiBool = false;
                        break;
                    }

                }
            }

            return tohiBool;
        }

        //-----------montazam-----------------------
        public bool Montazam(int[,] matrix, int n)
        {
            bool montazamBool = true;


            for (int i = 0; i < RowTotal(matrix, n).Length - 1; i++)
            {
                if (RowTotal(matrix, n)[i] != RowTotal(matrix, n)[i + 1])
                {
                    montazamBool = false;
                    break;
                }
            }

            return montazamBool;
        }

        //-----kamel-------------------------------
        public bool Kamel(int[,] matrix, int n)
        {
            bool kamel = true;


            for (int i = 0; i < n; i++)
            {
                if (RowTotal(matrix, n)[i] + 1 != n)
                {
                    kamel = false;
                    break;
                }
            }

            return kamel;

        }

        //--------jahatdar------------------------

        public bool Jahatdar(int[,] matrix, int n)
        {
            bool jahatdarBool = false;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0 ; j < i ; j++)
                {
                    if (matrix[i, j] != matrix[j , i])
                    {
                        jahatdarBool = true;
                        break;
                    }

                }
            }

            return jahatdarBool;
        }
        //--------GoThrough-----------------------------

        public void GoThrough(int[,] matrix , int n , int totalNode )
        {
            
            if (!isPassed[n])
                isPassed[n] = true;
            for (int i = 0; i < totalNode ; i++)
            {
                if(matrix[n , i] ==1 && n!= i)
                {
                    if (!isPassed[i])
                        GoThrough(matrix , i , totalNode);
                }
            }
        }

        //---------hamband------------------------------

        public bool Hamband(int[,] matrix , int totalNode )
        {
            isPassed = new bool[totalNode];

            GoThrough(matrix , 0 , totalNode);

            for (int i = 0; i < totalNode ; i++)
                if (!isPassed[i])
                    return false;
            return true;
        }

        //---------madari-----------------------------------

        public bool Madari(int[,] matrix, int n)
        {
            bool madariBool = false;

            if(Hamband(matrix, n) && RowTotal(matrix, n)[1] == 2)
            {
                madariBool = true; 
            }
            else
            {
                madariBool = false; 
            }

                return madariBool;
        }

        //---------charkhi--------------------------------

        public bool Charkhi(int[,] matrix, int n)
        {
            bool charkhiBool = true;

            if (Hamband(matrix , n))
            {
                bool NodeWith_n_1 = false;
                bool Nodes_3_degree = false;

                for(int i = 0; i < RowTotal(matrix , n).Length; i++)
                {
                    if(RowTotal(matrix , n)[i] == n - 1 && !NodeWith_n_1)
                    {
                        NodeWith_n_1 = true; 
                    }
                    else if(RowTotal(matrix, n)[i] != 3 )
                    {
                        Nodes_3_degree = false;  
                    }
                }

                if (Nodes_3_degree && NodeWith_n_1)
                {
                    charkhiBool = true;
                }
                else
                    charkhiBool = false;
            }

            return charkhiBool; 
           
        }

        //---------2bakhshi------------------------------------








    }
}
