﻿using System;
using System.Collections.Generic;
using System.Text;

namespace graph
{
    class Yekrikhti
    {
        public int[,] Jabjae(int[,] matrix, int n ,int i , int j)
        {
            int[,] temp1 = new int[n, n];
            int[,] temp2 = new int[n, n];

            for(int k=0; k < n; k++)
            {
                temp1[j, k] = matrix[i, k];
                temp1[i, k] = matrix[j, k];

            }

            for(int k=0; k < n; k++)
            {
                if( k != j && k != i)
                {
                    for(int p=0; p<n; p++)
                    {
                        temp1[k, p] = matrix[k, p];
                    }
                }
            }

            for(int k=0; k<n; k++)
            {
                temp2[k, j] = temp1[k, i];
                temp2[k, i] = temp1[k, j];

            }

            for (int k = 0; k < n; k++)
            {
                if (k != j && k != i)
                {
                    for (int p = 0; p < n; p++)
                    {
                        temp2[p, k] = temp1[p, k];
                    }
                }
            }
            return temp2;

        }

        public bool Equall(int[,] matrix_a, int[,] matrix_b, int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (matrix_a[i, j] != matrix_b[i, j])
                        return false;
                }
            }
            return true;
        }

        public bool YekrikhtiCheck(int[,] matrix_a , int n1 , int[,] matrix_b , int n2)
        {
            if(n1 != n2)
            {
                return false;
            }
            
            for (int i=0; i <n1; i++)
            {
                for(int j =i +1; j <n1; j++)
                {
                    if(Equall(matrix_a , Jabjae(matrix_b, n2, i, j) , n1 ) )
                    {
                        return true; 
                    }

                }
            }
            

            return false; 
        }
    }
}
