﻿using System;
using System.Collections.Generic;
using System.Text;

namespace graph
{
    class GetVoghu
    {
        int[,] voghuMatrix;
        

        //----------CalculateYalNum----------------------

        public int CalculateYalNum(int[,] matrix, int n)
        {
            GraphKinds g2 = new GraphKinds();

            int degree = 0;

            for(int i=0; i< g2.RowTotal(matrix, n).Length; i++)
            {
                degree += g2.RowTotal(matrix, n)[i]; 
            }

            int yalNum = degree / 2;

            return yalNum; 
        }
        //----------------------------------------------------------------

        private bool Contain(int[,] E_V, int a, int b , int yals)
        {
            for (int i = 0; i < yals ; i++)
            {
                if ((E_V[i, 0] == a && E_V[i, 1] == b) || (E_V[i, 0] == b && E_V[i, 1] == a))
                    return true;
            }
            return false;
        }
        //--------------------------------------------------

        public void VoghuMatrix(int[,] matrix , int n)
        {
            int counterE = 0;
            int yalNumber = CalculateYalNum(matrix, n);
            

            voghuMatrix = new int[n , yalNumber];

            int[,] temp = new int[yalNumber , 2] ;
            int counter = 0; 

            for(int i=0; i < n; i++)
            {
                for(int j =0; j < n; j++)
                {
                    if (i == j)
                        continue; 
                    else if(matrix[i,j] == 1)
                    {

                        

                        if(!Contain(temp , i ,j , yalNumber))
                        {
                            temp[counter, 0] = i;
                            temp[counter, 1] = j;

                            counter++; //shomarande temp

                            voghuMatrix[i, counterE] = 1;
                            voghuMatrix[j, counterE] = 1;
                            counterE++;
                            
                        }
                    }
                }
            }
            Console.WriteLine("VOGHU MATRIX : ");

            for(int i =0; i< n; i++)
            {
                for(int j=0; j < yalNumber; j++)
                {
                    Console.Write(voghuMatrix[i , j] + " ");
                }
                Console.WriteLine();
            }




        }
    }
}
