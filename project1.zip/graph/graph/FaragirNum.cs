﻿using System;
using System.Collections.Generic;
using System.Text;

namespace graph
{
    class FaragirNum
    {
        public int[,] d_matrix;
        public int[,] q_matrix;
        public int[,] q_bar_matrix;
        public int determinan;

        //---------D_matrix--------------------------------------------------
        public void Calculate_D_Matrix(int[,] matrix , int n)
        {
            GraphKinds g1 = new GraphKinds();

            d_matrix = new int[n, n]; 
            
            for(int i=0; i < n; i++)
            {
                for(int j=0; j<n; j++)
                {
                    if (i == j)
                    {
                        d_matrix[i, j] = g1.RowTotal(matrix, n)[i];
                    }
                    else
                        d_matrix[i, j] = 0;
                }
            }

            Console.WriteLine("THE D_MATRIX IS : ");
            for(int i=0; i< n; i++)
            {
                for(int j=0; j< n; j++)
                {
                    Console.Write(d_matrix[i,j] + " " );
                }
                Console.WriteLine();
            }

        }
        //---------Q_MATRIX-------------------------------------------------

        public void Calculate_Q_Matrix(int[,] matrix_a , int n )
        {
            q_matrix = new int [n, n]; 

            for(int i =0; i < n; i++)
            {
                for(int j=0; j< n; j++)
                {
                    q_matrix[i, j] = ( d_matrix[i, j] ) - ( matrix_a[i, j] ); 
                }
            }

            Console.WriteLine("THE Q_MATRIX IS : ");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(q_matrix[i, j] + " ");
                }
                Console.WriteLine();
            }

        }

        //------------Q_BAR_MATRIX---------------------------------------------

        public void Calculate_Q_Bar_Matrix(int n)
        {
            q_bar_matrix = new int [n-1 , n-1];

            for(int i=1 ; i< n ; i++)
            {
                for(int j =1 ; j<n ; j++)
                {
                    q_bar_matrix[i - 1, j - 1] = q_matrix[i, j];

                }
            }
            Console.WriteLine("Q_BAR_MATRIX LENGTH IS : " + q_bar_matrix.Length );
            Console.WriteLine("THE Q_BAR_MATRIX IS : ");
            for (int i = 0; i < n-1; i++)
            {
                for (int j = 0; j < n-1; j++)
                {
                    Console.Write(q_bar_matrix[i, j] + " ");
                }
                Console.WriteLine();
            }
        }

        //---------Determinan-----------------------------------------------------

        public void CalculateDeterminan ( int n)
        {
            int matrixSize = n-1 ;
            
            //int matrixSize = (n * n) - ((2 * n) - 1) /2 ; 

            if(matrixSize == 2)
            {
                determinan = (q_bar_matrix[0, 0] * q_bar_matrix[1, 1]) - (q_bar_matrix[0, 1] * q_bar_matrix[1, 0]);

                Console.WriteLine(" THE DETERMINAN OF YOUR Q_BAR_MATRIX IS :  ... " + determinan);

            }
            else if (matrixSize == 3)
            {
                determinan = (q_bar_matrix[0, 0] * ((q_bar_matrix[1, 1] * q_bar_matrix[2, 2]) - (q_bar_matrix[1, 2] * q_bar_matrix[2, 1]))) -
                               (q_bar_matrix[0, 1] * ((q_bar_matrix[1, 0] * q_bar_matrix[2, 2]) - (q_bar_matrix[1, 2] * q_bar_matrix[2, 0]))) +
                               (q_bar_matrix[0, 2] * ((q_bar_matrix[1, 0] * q_bar_matrix[2, 1]) - (q_bar_matrix[1, 1] - q_bar_matrix[2, 0])));

                Console.WriteLine(" THE DETERMINAN OF YOUR Q_BAR_MATRIX IS :  " + determinan);
            }
            else if(matrixSize > 3)
            {
                determinan = 0; 
                Console.WriteLine("DETERMIN OF YOUR Q_BAR_MATRIX : PLZ USE A MATRIX CALCULATOR ... ");
            }
        }
        public void CalculateFaragirNum()
        {
           if(determinan != 0)
            {
                Console.WriteLine(" TEDAD DERAKHT hAYE FARAGIR = " + determinan);
            }
           else
                Console.WriteLine("TEDAD DERAKHT hAYE FARAGIR = WE COULDN'T CALCULATE IT  :( ...");
        }
    }
}
